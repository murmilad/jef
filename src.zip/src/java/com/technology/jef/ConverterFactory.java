package com.technology.jef;

public interface ConverterFactory {

}
